# Countdown Timer Test (Render.com)

This repository deploys a simple PHP app with Imagick on Render.com.
Use it to verify Imagick works before adding the full countdown timer script.

## Quick deploy steps

1. Push this folder to a new GitHub repo (e.g., countdown-timer)
2. In Render.com, click **New > Web Service** and connect the repo
3. Choose environment: **Docker**
4. Keep the Free plan, deploy
5. Visit https://your-app-name.onrender.com/countdown_gif.php

If you see "Imagick is working!", you’re ready to replace the stub
with the full countdown_gif.php script.
